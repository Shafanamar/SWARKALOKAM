const cmdIcons = {
    dotIcon: 'https://cdn.discordapp.com/emojis/915658913850998794.gif',
    serverinfoIcon : 'https://cdn.discordapp.com/emojis/942629018296025128.gif',
};

module.exports = cmdIcons;